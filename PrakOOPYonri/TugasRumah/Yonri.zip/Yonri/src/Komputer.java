/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author 62821
 */
public abstract class Komputer {
    // Deklarasi atribut private merek, spesifikasi, dan hargaSewa
    private String merek;
    private String spesifikasi;
    private int hargaSewa;

    // Konstruktor overload dengan Merek dan Tahun Merek
    // Konstruktor digunakan untuk menginisialisasi objek Komputer dengan Merek, Tahun Merek, Spesifikasi, dan Harga Sewa.
    public Komputer(String merek, int modelYear, String spesifikasi, int hargaSewa) {
        // Menggabungkan Merek dan Tahun Merek, dan mengatur atribut lainnya.
        this.merek = merek + " " + modelYear;
        this.spesifikasi = spesifikasi;
        this.hargaSewa = hargaSewa;
    }

    // Getter dan Setter digunakan untuk mengakses dan mengubah nilai dari atribut private merek.
    // Metode Getter untuk mengambil nilai dari Merek.
    public String getMerek() {
        return merek;
    }

    // Metode Setter untuk mengatur nilai Merek.
    public void setMerek(String merek) {
        this.merek = merek;
    }

    // Metode Setter overload untuk mengatur Merek dengan Tahun Merek.
    public void setMerek(String merek, int modelYear) {
        this.merek = merek + " " + modelYear;
    }

    // Getter dan Setter digunakan untuk mengakses dan mengubah nilai dari atribut private spesifikasi.
    // Metode Getter untuk mengambil nilai Spesifikasi.
    public String getSpesifikasi() {
        return spesifikasi;
    }

    // Metode Setter untuk mengatur nilai Spesifikasi.
    public void setSpesifikasi(String spesifikasi) {
        this.spesifikasi = spesifikasi;
    }

    // Metode Setter overload untuk mengatur Spesifikasi dengan flag gaming.
    public void setSpesifikasi(String spesifikasi, boolean gaming) {
        // Menambahkan "(Gaming)" ke Spesifikasi jika flag gaming adalah true.
        this.spesifikasi = spesifikasi + (gaming ? " (Gaming)" : "");
    }

    // Getter dan Setter digunakan untuk mengakses dan mengubah nilai dari atribut private hargaSewa.
    // Metode Getter untuk mengambil nilai Harga Sewa.
    public double getHargaSewa() {
        return hargaSewa;
    }

    // Metode Setter untuk mengatur nilai Harga Sewa.
    public void setHargaSewa(int hargaSewa) {
        this.hargaSewa = hargaSewa;
    }

    // Metode Setter overload untuk mengatur Harga Sewa dengan persentase diskon dan menangani eksepsi.
    public void setHargaSewa(int hargaSewa, int discountPercentage) {
        try {
            if (discountPercentage < 0 || discountPercentage > 100) {
                throw new IllegalArgumentException("Discount percentage must be between 0 and 100.");
            }

            // Mengaplikasikan diskon ke Harga Sewa berdasarkan persentase yang diberikan.
            this.hargaSewa = hargaSewa - (hargaSewa * discountPercentage / 100);
        } catch (IllegalArgumentException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }

    // Metode untuk menampilkan informasi detail tentang Komputer.
    public void tampilkanInfoKomputer() {
        System.out.println("Merek: " + merek);
        System.out.println("Spesifikasi: " + spesifikasi);
        System.out.println("Harga Sewa per Hari: " + hargaSewa);
    }

    // Metode overload untuk menampilkan informasi berdasarkan parameter 'detailed'.
    public void tampilkanInfoKomputer(boolean detailed) {
        if (detailed) {
            // Menampilkan informasi detail.
            System.out.println("Merek: " + merek);
            System.out.println("Spesifikasi: " + spesifikasi);
            System.out.println("Harga Sewa per Hari: " + hargaSewa);
        } else {
            // Menampilkan informasi dasar (hanya Merek).
            System.out.println("Merek: " + merek);
        }
    }
    
    // Method abstract untuk memproses hasil inputan dari JTextField ke dalam jTable.
    public abstract void prosesInputKeTabel(DefaultTableModel tableModel, String merek, String tahunMerek, String spesifikasi, double hargaSewa, String diskon);
}