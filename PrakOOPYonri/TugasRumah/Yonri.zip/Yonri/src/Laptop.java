/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author 62821
 */
public class Laptop extends Komputer implements Rentable{
    private String tipeLaptop;

    public Laptop(String merek, String spesifikasi, double hargaSewa, String tipeLaptop, int modelYear) {
        super(merek, modelYear, spesifikasi, hargaSewa);
        this.tipeLaptop = tipeLaptop;
    }

    public String getTipeLaptop() {
        return tipeLaptop;
    }

    public void setTipeLaptop(String tipeLaptop) {
        this.tipeLaptop = tipeLaptop;
    }

    @Override
    public void tampilkanInfoKomputer() {
        super.tampilkanInfoKomputer();
        System.out.println("Tipe Laptop: " + tipeLaptop);
    }

    @Override
    public void prosesInputKeTabel(DefaultTableModel tableModel, String merek, String tahunMerek, String spesifikasi, double hargaSewa, String diskon) {
        double hargaDiskon = hargaSewa - (hargaSewa * Double.parseDouble(diskon) / 100);
        tableModel.addRow(new Object[]{merek, spesifikasi, hargaDiskon, tipeLaptop});
    }
    
    // Implementasi metode dari interface Rentable
    @Override
    public void prosesInputKeTabel(DefaultTableModel tableModel, String merek, String spesifikasi, double hargaSewa, String diskon) {
        // Implementasi method untuk memproses hasil inputan dari JTextField ke dalam jTable pada class Laptop.
        double hargaDiskon = hargaSewa - (hargaSewa * Double.parseDouble(diskon) / 100);
        tableModel.addRow(new Object[]{merek, spesifikasi, hargaDiskon, tipeLaptop});
    }
}