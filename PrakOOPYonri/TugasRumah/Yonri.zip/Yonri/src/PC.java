/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author 62821
 */
public class PC extends Komputer {
    private int coreCount;

    public PC(String merek, String spesifikasi, double hargaSewa, int coreCount, int modelYear) {
        super(merek, modelYear, spesifikasi, hargaSewa);
        this.coreCount = coreCount;
    }

    public int getCoreCount() {
        return coreCount;
    }

    public void setCoreCount(int coreCount) {
        this.coreCount = coreCount;
    }

    @Override
    public void tampilkanInfoKomputer() {
        super.tampilkanInfoKomputer();
        System.out.println("Jumlah Core: " + coreCount);
    }

    @Override
    public void prosesInputKeTabel(DefaultTableModel tableModel, String merek, String tahunMerek, String spesifikasi, double hargaSewa, String diskon) {
        double hargaDiskon = hargaSewa - (hargaSewa * Double.parseDouble(diskon) / 100);
        tableModel.addRow(new Object[]{merek, spesifikasi, hargaDiskon, coreCount});
    }
}