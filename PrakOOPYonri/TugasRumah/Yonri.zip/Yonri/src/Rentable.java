/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author 62821
 */
public interface Rentable {
    void prosesInputKeTabel(DefaultTableModel tableModel, String merek, String spesifikasi, double hargaSewa, String diskon);
}
